package UI;

import dados.Disciplina;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import persistencia.*;
import negocio.Sistema;

public class TelaPrincipal extends JFrame{
    
    
    JTextField txtArea;
    
    JPanel tela1 = new JPanel();
    JPanel tela2 = new JPanel();
    JPanel tela3 = new JPanel();
    JPanel tela4 = new JPanel();
 
    private JButton botao1 = new JButton ("Banco de Dados");
    private JButton botao2 = new JButton ("Gerar PDF");
    
    
    public TelaPrincipal(){
        try{
            Sistema sys = new Sistema();
        }catch(SQLException | ClassNotFoundException ds){
            System.out.println("Erro!!");
        }
        
        setTitle("Bem Vindo");
        setBounds(300, 300, 200, 200);
        this.setSize( 300 , 300);
        setContentPane(tela1);
        setLayout(new BorderLayout());
        tela1.setLayout(null);
        tela1.add(new JPanel(), BorderLayout.CENTER); 
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        botao1.setBounds(50, 50, 50, 50);
        botao1.setVisible(true);
        tela1.add(botao1);
        
        
    }
    
    public static Sistema Controller(){
        Sistema sys = null; 
        try{
            sys = new Sistema();
        }catch(SQLException | ClassNotFoundException ds){
            System.out.println("Erro!!");
        }
        return sys;
    }
    
    public void Tela2(){
        setTitle("Cadastro e exclusão de disciplinas, semestres e avaliações");
        setBounds(300, 300, 200, 200);
        setContentPane(tela2);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        tela2.setLayout(null);
        tela2.add(new JFrame(), BorderLayout.NORTH);
        botao2.add(new JButton());
    }
    
    public void Tela3(){
        
        setTitle("Banco de dados");
        setBounds(300, 300, 200, 200);
        setContentPane(tela3);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        tela3.setLayout(null);
        tela3.add(new JFrame(), BorderLayout.NORTH);
       
    }
    
    public void Tela4(){
        setTitle("Tabela Exame");
        setBounds(300, 300, 200, 200);
        setContentPane(tela4);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        tela4.setLayout(null);
        tela4.add(new JFrame(), BorderLayout.NORTH);
    }
    
    public void criarBotao1(){
        botao1.setBounds(50, 50, 50, 50);
        tela1.add(botao1);
        botao1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Usuários cadastrados");
                txtArea.getText();
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });   
    }
    
    public void criarBotao2(){
        botao2.setBounds(50, 50, 50, 50);
        tela2.add(botao2);
        botao2.addActionListener(new ActionListener() {
            private Disciplina disc;
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Usuários cadastrados no Banco de dados");
                Controller().removerDisciplina(disc);
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });  
    }
    
    
}
