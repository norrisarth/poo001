package negocio;

import dados.*; 
import persistencia.*;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author arthur
 */
public class Sistema {
    private AlunoDAO alunos;
    private DisciplinaDAO disciplinas;
    private SemestreDAO semestres;
    private AvaliacaoDAO aval;
    
    public Sistema() throws SQLException, ClassNotFoundException {
        alunos = AlunoDAO.getInstance();
        disciplinas = DisciplinaDAO.getInstance();
        semestres = SemestreDAO.getInstance();
        aval = AvaliacaoDAO.getInstance();
        
    }
    public boolean cadastrarAluno(Aluno al) throws SQLException, ClassNotFoundException{
        alunos.insert(al);
        return false;
    }
    public void cadastraDisciplina(Disciplina disc) throws SQLException, ClassNotFoundException {

        disciplinas.insert(disc);
    }
    public boolean removerDisciplina(Disciplina disc){
        disciplinas.delete(disc);
        return false;
    }
    public void cadastrarSemestre(Semestre semestre) throws SQLException {

        semestres.insert(semestre);
    }
    public float calculaMedia(Aluno al, Disciplina disc){
        List<Avaliacao> aval = disciplinas.Avaliacoes(disc, al);
        float Exame = 0.00F;
        float Mf = 0;
        for (Avaliacao a : aval){
            Mf += a.getNota();
        }

        if (Mf >= 1.7 && Mf < 7){
            Exame += 1.5 * Mf + 12.5;
        }
        else{
            System.out.println("Aluno não está em exame");
        }
        return Exame;
    }
}
