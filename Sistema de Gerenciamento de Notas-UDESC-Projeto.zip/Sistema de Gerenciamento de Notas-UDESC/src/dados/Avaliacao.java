/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

/**
 * Cadastro de avaliações por disciplinas no semestre;
 * @author arthur
 */
public class Avaliacao extends Disciplina{

    private  String nome;
    protected long matricula_aluno;
    protected long id_disciplina;
    private float peso;
    private float nota;
    private int dia;
    private int mes;
    private long ano;

    public Avaliacao() {
        super();
    }

    @Override
    public String getNome() {

        return nome;
    }

    @Override
    public void setNome(String nome) {

        this.nome = nome;
    }

    public long getMatricula_aluno() {

        return matricula_aluno;
    }

    public void setMatricula_aluno(long matricula_aluno)
    {
        this.matricula_aluno = matricula_aluno;
    }

    @Override
    public long getId_disciplina() {
        return id_disciplina;
    }

    @Override
    public void setId_disciplina(long id_disciplina) {
        this.id_disciplina = id_disciplina;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getNota() {
        return nota;
    }

    public void setNota(float nota) {

        this.nota = nota;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    @Override
    public long getAno() {
        return ano;
    }

    @Override
    public void setAno(long ano) {
        this.ano = ano;
    }

    @Override
    public String toString() {
        return "Avaliacao{" +
                "nome='" + nome + '\'' +
                ", matricula_aluno=" + matricula_aluno +
                ", id_disciplina=" + id_disciplina +
                ", peso=" + peso +
                ", nota=" + nota +
                ", dia=" + dia +
                ", mes=" + mes +
                ", ano=" + ano +
                '}';
    }
}
