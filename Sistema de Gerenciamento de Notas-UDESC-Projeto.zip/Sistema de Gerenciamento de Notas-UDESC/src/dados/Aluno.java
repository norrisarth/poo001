/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

/**
 * Camada de dados onde serão inseridos os dados do aluno;
 * @author arthur
 */
public class Aluno {

    private long matricula;
    protected int senha;
    private long  id;
    private String email;
    private String nome;
    protected String login;

    public Aluno(){
        this.login=" ";
    }

    public static void add() {
    }

    public String getNome(){
        return nome;
    }
    public void setNome(String nome){
        this.nome = nome;
    }

    public long getMatricula() {
        return matricula;
    }

    public void setMatricula(long matricula) {
        this.matricula = matricula;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    @Override
    public String toString() {
        return "Aluno{" +
                "matricula=" + matricula +
                ", senha=" + senha +
                ", id=" + id +
                ", email='" + email + '\'' +
                ", nome='" + nome + '\'' +
                ", login='" + login + '\'' +
                '}';
    }
}
