/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

/**
 *
 * @author arthur
 */
public class Semestre {
    private long ano;
    protected int id;
    private int fase = 0;

    public Semestre(){
        super();
    }

    public long getAno() {
        return ano;
    }

    public void setAno(long ano) {
        this.ano = ano;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFase() {
        return fase;
    }

    public void setFase() {
        this.fase = fase;
    }

    @Override
    public String toString() {
        return "Semestre{" +
                "ano=" + ano +
                ", id=" + id +
                ", fase=" + fase +
                '}';
    }

    public String toString(int fase) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
