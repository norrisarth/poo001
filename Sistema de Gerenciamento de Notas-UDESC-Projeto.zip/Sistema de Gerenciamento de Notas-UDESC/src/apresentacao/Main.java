package apresentacao;
import dados.*;
import negocio.Sistema;
import persistencia.*;
import UI.TelaPrincipal;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
public class Main {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Sistema sistema = new Sistema();
        TelaPrincipal frame = new TelaPrincipal();
        
        frame.setVisible(true);
    }
}
