package persistencia;
import dados.Avaliacao;

import java.sql.*;
public class AvaliacaoDAO {

    private static AvaliacaoDAO aval = null;

    private final PreparedStatement selectNewId;
    private final PreparedStatement insert;
    private PreparedStatement selectAvaliacao;
    private final PreparedStatement delete;
    private final PreparedStatement update;

    public AvaliacaoDAO() throws SQLException, ClassNotFoundException {
        Connection conn = ConexaoDAO.getConexaoDAO();
        selectNewId = conn.prepareStatement("select nextval('id_avaliacao')");
        insert = conn.prepareStatement("insert into avaliacao values (?, ?, ?, ?, ?," +
                                       "?, ?, ?)");
        delete = conn.prepareStatement("delete from avaliacao where id_avaliacao = ? ");
        update = conn.prepareStatement("update avaliacao set nome=? set matricula_aluno=? set id_disciplina=?" +
                                        " set nota=? set peso=? where id_avaliacao = ? ");
    }
    public static AvaliacaoDAO getInstance() throws SQLException, ClassNotFoundException {

        if (aval == null){
            aval = new AvaliacaoDAO();
        }
        return aval;
    }

    private int selectNewId(){
        try{
            ResultSet rs = selectNewId.executeQuery();
            if(rs.next()){
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println("\n");
        }
        return 1;
    }

    public void insert(Avaliacao avaliacao){
        try{
            insert.setInt(1, selectNewId());
            insert.setInt(2, (int) avaliacao.getId_disciplina());
            insert.setInt(3, (int) avaliacao.getMatricula_aluno());
            insert.setString(4, avaliacao.getNome());
            insert.setFloat(5, Integer.parseInt(Float.toString(avaliacao.getPeso())));
            insert.setFloat(6, Integer.parseInt(Float.toString(avaliacao.getNota())));
            insert.setInt(7, avaliacao.getDia());
            insert.setInt(8, avaliacao.getMes());
            insert.setInt(9, (int) avaliacao.getAno());
            insert.executeUpdate();
        } catch (SQLException e) {
            System.out.println("\n");
        }
    }

    public void delete(Avaliacao avaliacao){
        try{
            delete.setInt(1, (int) avaliacao.getId_disciplina());
            delete.executeUpdate();
        } catch (SQLException e) {
            System.out.println("\n");
        }
    }

    public void update(Avaliacao avaliacao){
        try{
            update.setInt(1, (int) avaliacao.getId_disciplina());
            update.setInt(2, (int) avaliacao.getMatricula_aluno());
            update.setString(3,  avaliacao.getNome());
            update.setInt(4, (int) avaliacao.getNota());
            update.setInt(5, (int) avaliacao.getPeso());
            update.setInt(6, avaliacao.getDia());
            update.setInt(7, avaliacao.getMes());
            update.setInt(8, (int) avaliacao.getAno());
            update.executeUpdate();
        }catch(SQLException e){
            System.out.println("\n");
        }
    }
}
