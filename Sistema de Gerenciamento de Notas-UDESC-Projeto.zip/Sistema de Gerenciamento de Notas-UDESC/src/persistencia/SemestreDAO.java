/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;
import dados.Semestre;

import java.sql.PreparedStatement;
import java.sql.*;

/**
 *
 * @author arthur
 */
public class SemestreDAO {

    private static SemestreDAO smstr = null;

    private PreparedStatement selectNewId;
    private PreparedStatement insert;
    private PreparedStatement selectSemestre;
    private PreparedStatement delete;
    private PreparedStatement update;

    private SemestreDAO() throws SQLException, ClassNotFoundException {
        Connection conn = ConexaoDAO.getConexaoDAO();
        selectNewId = conn.prepareStatement("select nextval('id_semestre')");
        insert = conn.prepareStatement("insert into semestre values (?, ?)");
        delete = conn.prepareStatement("delete from semestre where idSemestre = ? ");
        update = conn.prepareStatement("update semestre set fase = ? where id_semestre = ?");
    }

    public static SemestreDAO getInstance() throws SQLException, ClassNotFoundException {

        if (smstr == null){
            smstr = new SemestreDAO();
        }
        return smstr;
    }

    private int selectNewId(){
        try{
            ResultSet rs = selectNewId.executeQuery();
            if (rs.next())
                return rs.getInt(1);
        }catch(SQLException e){
            System.out.println("Query incorreta!!");
        }
        return 1;

    }
    //Inserir semestre na query.
    public void insert(Semestre semestre) throws SQLException {

        try{
            insert.setInt(2,semestre.getFase());
            insert.setInt(3,semestre.getId());
            insert.executeUpdate();
        }catch(SQLException e){
            System.out.println("\n");
        }
    }
    //Deletar um semestre pelo id.
    public void delete(Semestre semestre){
        try{
            delete.setInt(1,semestre.getId());
            delete.executeUpdate();
        }catch(SQLException e){
            System.out.println("\n");
        }
    }
    //Atualizar a query.
    public void update(Semestre semestre){
        try{
            update.setInt(1,semestre.getId());
            update.setInt(2,semestre.getFase());
            update.executeUpdate();
        }catch(SQLException e){
            System.out.println("\n");
        }
    }
}
