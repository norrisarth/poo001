package persistencia;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
/**
 *
 * @author arthur
 */
public class ConexaoDAO {
    private static Connection conexao = null;
    public static Connection getConexaoDAO() throws ClassNotFoundException, SQLException {
        if (conexao == null){

            Class.forName("org.postgresql.Driver");
            String url = "jdbc:postgresql://localhost:5432/Aluno";
            conexao = DriverManager.getConnection(url, "postgres", "qft370$&ç");
        }
        return conexao;
    }
}
