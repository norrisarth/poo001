package persistencia;
import dados.Aluno;
import dados.Avaliacao;
import dados.Disciplina;
import dados.Semestre;

import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author arthur
 */
public class DisciplinaDAO {
    private static DisciplinaDAO disciplina = null;

    private final PreparedStatement selectNewId;
    private final PreparedStatement insert;
    private PreparedStatement selectDisciplina;
    private final PreparedStatement join;
    private final PreparedStatement delete;
    private final PreparedStatement update;
    private DisciplinaDAO() throws SQLException, ClassNotFoundException {
        Connection conn = ConexaoDAO.getConexaoDAO();
        selectNewId = conn.prepareStatement("select nextval('id_disciplina')");
        insert = conn.prepareStatement("insert into disciplina values (?, ?)");
        join = conn.prepareStatement("select * from avaliacao where id_disciplina = ? and id_aluno = ?");
        delete = conn.prepareStatement("delete from diciplina where idDisciplina = ?");
        update = conn.prepareStatement("update diciplina set  = ? where id_disciplina = ?");
    }

    public static DisciplinaDAO getInstance() throws SQLException, ClassNotFoundException {

        if (disciplina == null){
            disciplina = new DisciplinaDAO();
        }
        return disciplina;
    }

    private int selectNewId() {
        try{
            ResultSet rs = selectNewId.executeQuery();
            if (rs.next()){
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println("\n");
        }
        return 1;
    }

    public void insert(Disciplina disciplina){
        try{
            insert.setInt(1, selectNewId());
            insert.setInt(2, (int) disciplina.getId_disciplina());
        } catch (SQLException e) {
            System.out.println("\n");
        }
    }

    public List<Avaliacao> Avaliacoes(Disciplina disciplina, Aluno aluno){

        ArrayList<Avaliacao> aval = new ArrayList<>();

        try{

            join.setInt(2, (int) aluno.getId());
            join.setLong(1, disciplina.getId_disciplina());
            ResultSet rs = join.executeQuery();

            while(rs.next()){
                Avaliacao avl = new Avaliacao();
                avl.setNota(rs.getInt(6));
                avl.setPeso(rs.getInt(5));
                aval.add(avl);
            }
            return aval;
        } catch (SQLException e) {
            System.out.println("\n");
        }
        return null;
    }

    public void delete(Disciplina disciplina){
        try{
            delete.setInt(1, (int) disciplina.getId_disciplina());
            delete.executeUpdate();
        } catch (SQLException e) {
            e.getMessage();
        }
        
    }


}
