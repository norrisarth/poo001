package persistencia;

import dados.Aluno;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author arthur
 */
    public class AlunoDAO {
        private static AlunoDAO conexao = null;

        private PreparedStatement selectNewId;
        private PreparedStatement insert;
        private PreparedStatement selectAluno;
        private PreparedStatement tryAlunos;
        private AlunoDAO() throws SQLException, ClassNotFoundException {
            Connection conexao = ConexaoDAO.getConexaoDAO();
            selectNewId = conexao.prepareStatement("select nextval ('id_aluno')");
            insert = conexao.prepareStatement("insert into aluno values (?,?,?,?,?,?)");
            selectAluno = conexao.prepareStatement("select *from aluno where idAluno = ?");
            tryAlunos = conexao.prepareStatement("select idAluno from aluno where idAluno = ?");
        }

        public static AlunoDAO getInstance() throws SQLException, ClassNotFoundException {
            if(conexao == null){
                conexao = new AlunoDAO();
            }
            return conexao;
        }

        private int selectNewId() throws SQLException {

            try{
                ResultSet rs = selectNewId.executeQuery();
                if (rs.next()){
                    return rs.getInt(1);
                }
            }catch(SQLException e){
                System.out.println("Query incorreta");
            }
            return 1;
        }

        public boolean insert(Aluno aluno){


            try{

                insert.setInt(1, selectNewId());
                insert.setLong(2, aluno.getMatricula());
                insert.setString(3, aluno.getNome());
                insert.setString(4, aluno.getEmail());
                insert.setInt(5, aluno.getSenha());
                insert.setString(6, aluno.getLogin());
                insert.executeUpdate();
                return true;
            }catch(SQLException e){

            }
            return false;
        }

    }
